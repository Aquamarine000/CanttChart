function Pop = Initialization(Machine, Pop_num)
Pop = cell(Pop_num, 1);
%生成工序段编码OS
for Pop_index = 1:Pop_num
    OS= [];
    for i = [1:size(Machine,1)]
        for j= [1: size(Machine,2)]
            OS = [OS, i];
        end
    end
    %os=[1,1,1,2,2,2,3,3,3]
    %将工序段编码随机打乱
    OS= OS(randperm(length(OS)));
    Pop{Pop_index} = OS;
end
end