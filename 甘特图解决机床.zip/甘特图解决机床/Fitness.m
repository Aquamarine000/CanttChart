function F=Fitness(Pop_num, Camx_all)
F=zeros(Pop_num,1);

for i=1:Pop_num
    F(i)=1/Camx_all(i);
end
end
