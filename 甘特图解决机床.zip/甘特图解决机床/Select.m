function Pop_S = Select(Pop,Fitness, best_os, Pop_num)
k=2;% 每次选择两个os
Pop_S = cell(Pop_num,1);%存放选择出来的
p=zeros(k,1);% 存放选择出来的os位置
f=zeros(k,1);% 存放对应的适应度值

% 精英保留
Pop_S{1,1}= best_os;
for i = 2:Pop_num
    %随机选择样本
    for j = 1:k
        p(j)= unidrnd(Pop_num);% 随机返回两个下标 [2,43]
        f(j)=Fitness(p(j));%[0.21524, 0.47875]
    end
    % 选择个体
    if f(1) == f(2)
        choice = p(unidrnd(2));
    else
        index=find(f == max(f)); %返回矩阵中和指定元素相等的下标
        choice = p(index);
    end
    Pop_S{i,1}=Pop{choice,1};
end