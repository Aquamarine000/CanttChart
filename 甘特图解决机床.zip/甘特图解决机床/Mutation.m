function Pop_M = Mutation(Pop_C, Pop_num, Operation_sum, PM)
%互换变异
Pop_M= Pop_C;% 种群初始化
for i = 1:Pop_num
    if(rand(1)>PM)
    else
        % 随机选取两个要交换的工序
        o1= unidrnd(Operation_sum);
        o2= unidrnd(Operation_sum);
        while o1 == o2
            o2 = unidrnd(Operation_sum);
        end
        temp = Pop_M{i,1}(1,o1);
        Pop_M{i,1}(1,o1)=Pop_M{i,1}(1,o2);
        Pop_M{i,1}(1,o2)=temp;
    end
end