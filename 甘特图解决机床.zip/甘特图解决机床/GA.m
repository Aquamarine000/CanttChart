close;
clear;
clc;

Machine=[3 2 5 4 1;
         3 4 2 5 1;
         4 5 1 2 3;
         2 5 4 3 1;
         1 2 5 3 4];
Time=[3,2,1,2,4;
      2,2,4,3,2;
      3,5,2,3,1;
      2,2,4,1,3;
      4,3,1,2,2];
J_num =size(Machine,1);% 工件数
M_num =size(Machine,2);% 机器数
Operation=[];% 各工件对应的工序数

for o = 1:size(Machine,1)
    Operation=[Operation,size(Machine,2)];% 各工件对应的工序数
end
Operation_sum = sum(Operation);% 总工序数

%GA算法
Pop_num=50;% 种群数
D = 50;%迭代次数
PC=0.8;%交叉率
PM=0.1;%变异率
C_max=zeros(1,D);%各代最优值
Pop=Initialization(Machine,Pop_num);
for i = 1:D
    [Camx_all, best_os, best_operation_time, Cmax]=Decode(Pop, Machine, Time, Pop_num, J_num,Operation_sum,M_num);
    F=Fitness(Pop_num, Camx_all);
    Pop_S=Select(Pop,F, best_os, Pop_num);
    Pop_C = Crossover(Pop_S, Pop_num, J_num, Operation_sum, PC);
    Pop = Mutation(Pop_C, Pop_num, Operation_sum, PM);

    % 甘特图、折线图数据处理
    if i == 1
        C_max(1)=Cmax;
        B_OS = best_os;
        B_PT = best_operation_time;
        B_Cmax = Cmax;
    else
        if Cmax < B_Cmax
            C_max(i) = Cmax;
            B_OS = best_os;
            B_PT = best_operation_time;
             B_Cmax = Cmax;
        else
            C_max(i)=Cmax;
        end
    end
end
%迭代曲线
figure;
plot(1:D,C_max,'b','LineWidth',2);%制折线图
xlabel('迭代次数');
ylabel('最大完工时间');
hold on;


figure;
PG=zeros(Operation_sum,4);
w=0.5;
set(gcf,'color','white');
PC=zeros(J_num,1);
for i=1:Operation_sum
    o=B_OS(i);
    g=PC(o)+1;
    k=Machine(o,g);
    PC(o)=PC(o)+1;
    PG(i,1)=k;
    PG(i,2)=o*10+g; 
    PG(i,3)=B_PT(1,i);
    PG(i,4)=B_PT(2,i);
    x1=PG(i,[3 3 4 4]);
    y1=PG(i,1)+[-w/2 w/2 w/2 -w/2];
    p1=patch('xdata',x1,'ydata',y1,'facecolor','none','edgecolor','k','LineWidth',2);
    text(PG(i,3)+0.1,PG(i,1),num2str(PG(i,2)),'FontSize',15);
end
xlabel('加工时间','FontSize',22);
ylabel('机器','FontSize',22);
axis([0, B_Cmax, w/2, M_num+w/2]); 
set(gca,'FontSize',20,'LineWidth',1);
set(gca,'Box','off');
set(gca,'YTick',0:M_num+w/2);
set(gca,'YTickLabel',[{''};num2str((1:M_num)','M%d');{''}]);



