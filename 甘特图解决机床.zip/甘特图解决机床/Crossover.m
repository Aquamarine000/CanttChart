function Pop_C = Crossover(Pop_S, Pop_num, J_num, Operation_sum, PC)
%POX交叉
Pop_C= Pop_S;% 种群初始化

OS= randperm(Pop_num);% 将个体随机排序
J=randperm(J_num);% 将工件随机排序

for i=1:2:Pop_num % 因为是每次随机选两个os进行交叉,所以进行pop_num/2次循环
    if rand(1)>PC % rand(1)生成一个随机小数,判断是否进行交叉操作
    else
        % 选择两个随机种群
        p1= OS(i);
        p2 = OS(i+1);
        %选择要的固定机器号
        j1= unidrnd(J_num-1);% 至少要有一个工件要进行交叉
        j2 = unidrnd(J_num-1);
        if j1>j2 %若j1大于j2,交换j1、o2,保证j1小于j2
            temp=j1;
            j1=j2;
            j2=temp;
        end
        J1=J(j1:j2);%进行固定操作的随机工件集J1

        % 初始化两个os编码,用干存储交叉操作时的os
        os1 = zeros(1,Operation_sum);
        os2 = zeros(1,Operation_sum);

        % 将固定的机器号放入os1和os2中
        for j = 1:Operation_sum
            % 固定os1
            if(ismember(Pop_S{p1,1}(j),J1) == 1)
                os1(j)=Pop_S{p1}(j);
            end
            % 固定os2
            if(ismember(Pop_S{p2,1}(j),J1) == 1)
                os2(j)=Pop_S{p2}(j);
            end
        end
        k = 1;
        t = 1;
        for j = 1:Operation_sum
            % 交叉os1
            if ismember(Pop_S{p2,1}(1,j),J1) == 0
                while os1(k) ~= 0
                    k = k + 1;
                end
                % [0, 0, 1, 0, 1, 0, 0, 0, 1]
                os1(k)= Pop_S{p2,1}(1,j);
            end
            % 交叉os2
            if ismember(Pop_S{p1,1}(1,j),J1) == 0
                while os2(t) ~= 0
                    t = t + 1;
                end
            os2(t)= Pop_S{p1,1}(1,j);
            end
        end
        Pop_C{p1}=os1;
        Pop_C{p2}=os2;
    end
end