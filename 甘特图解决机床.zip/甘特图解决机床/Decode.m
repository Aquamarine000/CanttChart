function [Camx_all, best_os, best_operation_time, Cmax]=Decode(Pop, Machine, Time, Pop_num, J_num,Operation_sum,M_num)
% Camx_all;%各个体的最大完工时间
% best_os;%最优个体编码
% best_operation_time;%最优个体的各工序开工和完工时间
% Cmax=min(Camx_all);%最优个体的最大完工时间

Camx_all = zeros(1,Pop_num);
for pop_index = 1:Pop_num
    %初始化容器
    OS=Pop{pop_index};% 单个工序编码
    Operation_index= ones(1,J_num);% 工序计数器[1,1,1]
    Operation_time=zeros(2,Operation_sum);% 工序开始和完工时间
    J_stop=zeros(1,J_num);%工件完工时间[1,1,1]
    M_start=zeros(1,M_num);%机器可开工时间
    for i = 1:Operation_sum
        % 取出加工信息
        j=OS(i);%工件号
        o=Operation_index(j);% 工序号
        m=Machine(j,o);%加工机器
        t=Time(j,o);%加工时间
    
        %进行解码
        Operation_time(1, i)= max(M_start(m), J_stop(j));
        Operation_time(2, i) = Operation_time(1,i) +t;
        J_stop(j) = Operation_time(2, i);
        M_start(m) = Operation_time(2, i);
        Operation_index(j) = Operation_index(j)+1;
    end
    Camx_all(pop_index) = max(Operation_time(2,:));


    if pop_index == 1 
        best_os = OS;%最优个体编码
        best_operation_time = Operation_time;%最优个体的各工序开工和完工时间
        Cmax = Camx_all(1);%最优个体的最大完工时间
    else
        if Camx_all(pop_index) < Cmax
            best_os=OS;
            best_operation_time=Operation_time;
            Cmax=Camx_all(pop_index);
        end
    end
end
